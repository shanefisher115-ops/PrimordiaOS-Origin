# PrimordiaOS // Unreal Engine 5.8 Integration & Telemetry Guide

This guide explains how PrimordiaOS communicates with Unreal Engine 5.8 and how you can view, inspect, and bind incoming changes inside your Unreal Engine editor.

---

## 1. Architecture Overview

PrimordiaOS operates a real-time bidirectional telemetry gateway:
* **Masterplane Server**: Running on http://localhost:3000 (Node.js engine in server/sync.js).
* **WebSocket Gateway**: Live RFC6455 duplex streaming on ws://localhost:3000/ws.
* **Telemetry State Query**: REST endpoint at http://localhost:3000/api/unreal/state.
* **Signal Dispatch**: REST endpoint at http://localhost:3000/api/unreal/signal.

When you spawn planets, nudge entities, trigger spaghettification flares, or click **"🚀 Stream to UE 5.8"** in the WebGL Cockpit (http://localhost:3000/arcade), Primordia broadcasts high-precision actor transforms (x, y, z, scale, type) and Niagara particle trigger packets across the WebSocket gateway.

---

## 2. How to View What It's Changing in Unreal Engine 5.8

### Method A: Live In-Editor Blueprint WebSocket Bridge (Real-Time)

You can receive and view every single transform and event directly inside Unreal Engine 5.8:

1. **Enable Native UE 5 Plugins**:
   * Open your Unreal Engine 5.8 project.
   * Go to **Edit -> Plugins**.
   * Ensure **WebSockets** and **JSON Blueprint Utilities** are enabled (these are built into Unreal Engine 5).
   * Restart the editor if prompted.

2. **Create the WebSocket Bridge Blueprint**:
   * In your Content Browser, create a new Blueprint Actor named `BP_PrimordiaBridge`.
   * Open `BP_PrimordiaBridge` and go to the **Event Graph**.
   * On **Event BeginPlay**:
     - Add node: `Create WebSocket` (`URL: "ws://127.0.0.1:3000/ws"`, `Protocols: ["ws"]`).
     - Promote the returned WebSocket to a variable: `MyWebSocket`.
     - Call `Connect` on `MyWebSocket`.
   * Bind to **On Message**:
     - From `MyWebSocket`, assign an event to `On Message`.
     - Add a `Print String` node wired to `Message` (set Duration to 5.0, Color to Cyan).
     - Any time you move a planet or place an object in the browser, the exact JSON packet will print across your Unreal Engine viewport!

3. **View Incoming Logs in the Output Log**:
   * In Unreal Engine 5.8, open **Window -> Output Log** (or click the drawer at the bottom).
   * As you interact with http://localhost:3000/arcade, you will see live stream entries:
     ```text
     LogBlueprintUserMessages: [BP_PrimordiaBridge] {"type":"cosmic_field_stream","engineVersion":"5.8","actors":[{"id":"BP_Planet_magma_2","type":"planet_magma","x":190,"y":-20,"z":-70,"scale":1}],"timestamp":1789223000000}
     ```

4. **Procedural Actor & Niagara Updates**:
   * From `On Message`, call `Parse JSON` on the string.
   * Extract the `actors` array.
   * For each actor:
     - Find or spawn a corresponding Mesh/Niagara Actor by `id`.
     - Call `SetActorLocationAndRotation` passing `X, Y, Z` (mapping coordinates into Unreal: `X -> X`, `Z -> Y`, `Y -> Z`).
     - Update Niagara emitter parameters (e.g. `User.Mass`, `User.RocheProgress`).

---

### Method B: DaVinci Resolve Level Sequence Import

If you want to view camera flights and cinematic color grading in Unreal Engine 5.8:

1. Open the **DaVinci Resolve Studio 19** suite in the WebGL editor by pressing **`G`** or clicking **`🎨 DaVinci Editor [G]`**.
2. Click the **Sequencer** tab.
3. Click **🎬 Export Unreal 5.8 Level Sequence**.
4. This downloads `unreal58_davinci_sequence.json`, containing:
   * 4-shot cinematic flight keyframes (Wide Orbit, Accretion Edge, Polar Jet Top, Singularity Dive).
   * ACES color grading parameters (3D LUT mode, Contrast, Saturation, Kelvin Temperature).
5. In Unreal Engine 5.8:
   * Go to **Cinematics -> Add Level Sequence**.
   * Use Unreal's Python script or Sequencer Importer to load the camera tracks directly into your CineCameraActor.

---

### Method C: Browser Diagnostics & Telemetry Inspection

At any time, you can view what PrimordiaOS is actively sending to Unreal without even launching Unreal Engine:

1. Open **http://localhost:3000/api/unreal/state** in your browser.
2. It returns the live diagnostic JSON:
   ```json
   {
     "connected": true,
     "clients": 1,
     "engineVersion": "5.8",
     "emitterCount": 4,
     "lastPacket": "2026-09-12T07:25:00.000Z",
     "packetsSent": 184,
     "lastSignal": {
       "type": "cosmic_field_stream",
       "engineVersion": "5.8",
       "actors": [ ... ]
     }
   }
   ```

---

## 3. How to Run PrimordiaOS from this Package

1. Ensure **Node.js** (v18+) is installed.
2. Double-click `START_SERVER.bat` (or run `node server/sync.js`).
3. Open http://localhost:3000/arcade in your browser.
4. Open Unreal Engine 5.8 and connect `BP_PrimordiaBridge` to `ws://127.0.0.1:3000/ws`.

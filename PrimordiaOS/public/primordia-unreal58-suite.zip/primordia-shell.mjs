#!/usr/bin/env node
/**
 * PrimordiaOS Sovereign Interactive Shell REPL (psh)
 * Location: C:\primordiaos\primordia-shell.mjs
 * Combines millisecond deterministic disk execution + multi-turn conversational AI.
 */

import readline from "readline";
import path from "path";
import os from "os";
import { spawn, spawnSync } from "child_process";
import fs from "fs";
import { executeEnglishCommand, BADGES } from "./primordia-executor.mjs";
import { PrimordiaAgent } from "./primordia-agent.mjs";

const C = {
  reset: "\x1b[0m",
  bold: "\x1b[1m",
  dim: "\x1b[2m",
  cyan: "\x1b[36m",
  brightCyan: "\x1b[96m",
  gold: "\x1b[33m",
  brightYellow: "\x1b[93m",
  green: "\x1b[32m",
  brightGreen: "\x1b[92m",
  magenta: "\x1b[35m",
  brightMagenta: "\x1b[95m",
  red: "\x1b[31m",
  brightRed: "\x1b[91m",
  gray: "\x1b[90m",
  white: "\x1b[97m",
};

function printBanner(isOllamaOnline = true, activeModel = "llama3.2:latest") {
  console.clear();
  console.log(`${C.brightCyan}${C.bold}`);
  console.log(`  ____       _                         _ _         ____   ____ `);
  console.log(` |  _ \\ _ __(_)_ __ ___   ___  _ __ __| (_) __ _  / __ \\ / ___|`);
  console.log(` | |_) | '__| | '_ \` _ \\ / _ \\| '__/ _\` | |/ _\` |/ / _\` |\\___ \\ `);
  console.log(` |  __/| |  | | | | | | | (_) | | | (_| | | (_| | | (_| | ___) |`);
  console.log(` |_|   |_|  |_|_| |_| |_|\\___/|_|  \\__,_|_|\\__,_|\\ \\__,_||____/ `);
  console.log(`                                                  \\____/        ${C.reset}`);
  console.log(` ${C.gold}Sovereign English-to-Disk Conversational Shell [v4.2.0]${C.reset}`);
  console.log(` ${C.gray}Neural Engine:${C.reset} ${isOllamaOnline ? `${C.brightGreen}Ollama (${activeModel}) [ONLINE]${C.reset}` : `${C.brightRed}Ollama [OFFLINE]${C.reset}`} | ${C.gray}Cloud Substrate:${C.reset} ${C.brightCyan}AGY (Gemini 3.8 Flash) [READY]${C.reset}`);
  console.log(` ${C.gray}Talk naturally, give direct disk directives, or type ${C.white}"help"${C.gray} or ${C.white}"models"${C.reset}\n`);
}

function printHelp() {
  console.log(`\n${C.brightCyan}${C.bold}PrimordiaOS Shell Capabilities:${C.reset}`);
  console.log(`  ${C.gold}Natural Conversation & Autonomous Reasoning:${C.reset}`);
  console.log(`    • "What are you capable of?"`);
  console.log(`    • "Write a python script that tests my ping and save it as ping_test.py"`);
  console.log(`    • "Find all error logs on my desktop and summarize what failed"`);
  console.log(`    • "Explain how the Unreal Engine 5.4 Niagara bridge works"`);
  console.log(`\n  ${C.gold}Direct Millisecond Disk Operations:${C.reset}`);
  console.log(`    • create folder <path>`);
  console.log(`    • create file <path> with <content>`);
  console.log(`    • read file <path>`);
  console.log(`    • delete file <path>`);
  console.log(`    • show disk space / check memory / check cpu / show running processes`);
  console.log(`\n  ${C.gold}Special Directives:${C.reset}`);
  console.log(`    • agy           - Launch the full Antigravity Gemini 3.8 Cloud Agent`);
  console.log(`    • clear / cls   - Clear the screen`);
  console.log(`    • exit / quit   - Exit the Primordia shell\n`);
}

// Regex list of deterministic instant disk commands
const FAST_PATTERNS = [
  /^(?:show\s+)?(disk\s+space|storage|drives)$/i,
  /^(check\s+)?(memory(\s+usage)?|ram)$/i,
  /^(check\s+)?(cpu(\s+load|\s+usage)?|cores)$/i,
  /(show\s+)?(running\s+)?processes|process\s+list/i,
  /^(?:create\s+(?:folder|dir(?:ectory)?)|make\s+(?:folder|dir(?:ectory)?)|mkdir)\s+/i,
  /^(?:create|make)\s+file\s+/i,
  /^append\s+/i,
  /^(?:read\s+file|view\s+file|cat)\s+/i,
  /^(?:show\s+(?:the\s+)?first\s+\d+\s+lines?\s+of|head\s+-n\s+\d+)\s+/i,
  /^(?:delete\s+file|remove\s+file|rm)\s+/i,
  /^copy\s+/i,
  /^zip\s+/i,
  /^(?:show\s+)?largest\s+\d+\s+files/i,
  /^find\s+all\s+\w+\s+files/i,
  /^count\s+all\s+\w+\s+files/i,
  /^search\s+for\s+["'].+["']\s+in\s+files/i,
];

function isFastCommand(input) {
  return FAST_PATTERNS.some(re => re.test(input.trim()));
}

async function startREPL() {
  const agent = new PrimordiaAgent({ workingDir: process.cwd() });
  const isOnline = await agent.checkOnline();
  printBanner(isOnline, agent.model);

  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout,
    prompt: `${C.brightCyan}PRIMORDIA-OS${C.reset} ${BADGES.stable} ${C.gold}>>${C.reset} `
  });

  rl.prompt();

  rl.on("line", async (line) => {
    const input = line.trim();

    if (!input) {
      rl.prompt();
      return;
    }

    if (input === "exit" || input === "quit") {
      console.log(`\n${C.gold}Exiting Primordia Sovereign Shell.${C.reset}`);
      rl.close();
      process.exit(0);
    }

    if (input === "clear" || input === "cls") {
      printBanner(await agent.checkOnline(), agent.model);
      rl.prompt();
      return;
    }

    if (input === "help") {
      printHelp();
      rl.prompt();
      return;
    }

    // Launch AGY directly
    if (input === "agy" || input === "/agy") {
      console.log(`\n${C.brightCyan}Launching Antigravity Cloud Substrate (Gemini 3.8 Flash)...${C.reset}\n`);
      rl.pause();
      const agyProc = spawn("agy.exe", [], { stdio: "inherit", shell: true });
      agyProc.on("exit", () => {
        printBanner(true, agent.model);
        rl.resume();
        rl.prompt();
      });
      return;
    }

    // List local Ollama models
    if (input === "models" || input === "/models") {
      try {
        const res = await fetch("http://localhost:11434/api/tags");
        const data = await res.json();
        console.log(`\n${C.brightCyan}${C.bold}Installed Ollama Models:${C.reset}`);
        (data.models || []).forEach(m => {
          const isActive = m.name === agent.model || m.model === agent.model;
          const marker = isActive ? `${C.brightGreen}* (Active)${C.reset}` : "";
          const sizeGB = (m.size / 1073741824).toFixed(2);
          console.log(`  • ${C.white}${m.name.padEnd(25)}${C.reset} ${C.gray}[${sizeGB} GB]${C.reset} ${marker}`);
        });
        console.log(`\n  ${C.gray}Switch models anytime with: ${C.gold}model <name>${C.reset}\n`);
      } catch (e) {
        console.log(`\n${BADGES.error} Could not query local Ollama models: ${e.message}\n`);
      }
      rl.prompt();
      return;
    }

    // Switch active model (with auto-pull if not yet downloaded)
    const modelSwitchMatch = input.match(/^(?:\/)?model\s+([\w.:-]+)$/i);
    if (modelSwitchMatch) {
      const newModel = modelSwitchMatch[1].trim();
      let isInstalled = false;
      try {
        const res = await fetch("http://localhost:11434/api/tags");
        const data = await res.json();
        isInstalled = (data.models || []).some(m => m.name === newModel || m.name.startsWith(newModel + ":") || m.model === newModel);
      } catch (_) {}

      if (!isInstalled) {
        console.log(`\n${BADGES.flux} ${C.gold}Model "${newModel}" is not yet downloaded.${C.reset}`);
        console.log(`  ${C.brightCyan}Initiating automatic pull via Ollama...${C.reset}\n`);
        rl.pause();
        spawnSync("ollama.exe", ["pull", newModel], { stdio: "inherit", shell: true });
        rl.resume();
      }

      agent.model = newModel;
      try {
        fs.writeFileSync("C:\\primordiaos\\config.json", JSON.stringify({ model: newModel }, null, 2), "utf8");
        console.log(`\n${BADGES.stable} ${C.green}Active neural model set to:${C.reset} ${C.brightCyan}${newModel}${C.reset}\n`);
      } catch (e) {
        console.log(`\n${BADGES.error} Could not save model preference: ${e.message}\n`);
      }
      rl.prompt();
      return;
    }


    // Direct millisecond deterministic execution
    if (isFastCommand(input)) {
      try {
        await executeEnglishCommand(input, process.cwd());
      } catch (err) {
        console.error(`${BADGES.error} ${err.message}`);
      }
      console.log();
      rl.prompt();
      return;
    }

    // Conversational & Autonomous Reasoning Turn
    try {
      let lastStatus = "";
      const reply = await agent.send(input, (status) => {
        if (status !== lastStatus) {
          console.log(`  ${status}`);
          lastStatus = status;
        }
      });
      console.log(`\n${C.brightCyan}${C.bold}Primordia >>${C.reset} ${reply}\n`);
    } catch (err) {
      console.error(`\n${BADGES.error} ${err.message}\n`);
    }

    rl.prompt();
  });

  rl.on("close", () => {
    process.exit(0);
  });
}

startREPL();

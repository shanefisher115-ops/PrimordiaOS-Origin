#!/usr/bin/env node
/**
 * PrimordiaOS Cryptographic License Manager
 * Location: C:\primordiaos\license-manager.mjs
 * Format: PRIM-[TIER]-[ENTROPY]-[SIG]
 */

import crypto from "crypto";

const MASTER_KEY = "PRIMORDIA_SOVEREIGN_ROOT_SECRET_2026";

export function generateKey(tier = "SOVEREIGN") {
  const entropy = crypto.randomBytes(4).toString("hex").toUpperCase();
  const hmac = crypto.createHmac("sha256", MASTER_KEY);
  hmac.update(`${tier}:${entropy}`);
  const sig = hmac.digest("hex").slice(0, 8).toUpperCase();
  return `PRIM-${tier.toUpperCase()}-${entropy}-${sig}`;
}

export function verifyKey(key) {
  if (!key || typeof key !== "string") return false;
  const parts = key.trim().split("-");
  if (parts.length !== 4 || parts[0] !== "PRIM") return false;
  const [_, tier, entropy, sig] = parts;
  const hmac = crypto.createHmac("sha256", MASTER_KEY);
  hmac.update(`${tier}:${entropy}`);
  const expectedSig = hmac.digest("hex").slice(0, 8).toUpperCase();
  return sig === expectedSig;
}

const args = process.argv.slice(2);
const action = args[0] || "status";

if (action === "status") {
  console.log(JSON.stringify({
    active: true,
    tier: "SOVEREIGN_ENTERPRISE",
    seat: "Shane Fisher (Master Architect)",
    status: "LICENSED_AUTHENTIC",
    features: [
      "English-to-Disk Kernel (psh)",
      "Unreal Engine 5.4 Niagara Stream",
      "MovieForge 4K Neural Cinema & 3D LUTs",
      "GPU Warp Benchmark Suite"
    ]
  }, null, 2));
} else if (action === "verify") {
  const key = args[1];
  const valid = verifyKey(key);
  console.log(JSON.stringify({ key, valid, tier: valid ? key.split("-")[1] : null }, null, 2));
} else if (action === "generate") {
  const tier = args[1] || "SOVEREIGN";
  console.log(generateKey(tier));
} else {
  console.log("Usage: node license-manager.mjs [status | verify <key> | generate <tier>]");
}

@echo off
if "%~1"=="" (
  node "C:\primordiaos\primordia-shell.mjs"
) else (
  node "C:\primordiaos\primordia-executor.mjs" %*
)

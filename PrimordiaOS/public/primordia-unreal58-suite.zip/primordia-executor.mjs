#!/usr/bin/env node
/**
 * PrimordiaOS Sovereign English-to-Disk Semantic Executor (PCE)
 * Location: C:\primordiaos\primordia-executor.mjs
 */

import fs from "fs";
import path from "path";
import os from "os";
import { execSync } from "child_process";

// ANSI Color Tokens
const C = {
  reset: "\x1b[0m",
  bold: "\x1b[1m",
  dim: "\x1b[2m",
  cyan: "\x1b[36m",
  brightCyan: "\x1b[96m",
  gold: "\x1b[33m",
  brightYellow: "\x1b[93m",
  green: "\x1b[32m",
  brightGreen: "\x1b[92m",
  magenta: "\x1b[35m",
  brightMagenta: "\x1b[95m",
  red: "\x1b[31m",
  brightRed: "\x1b[91m",
  gray: "\x1b[90m",
  white: "\x1b[97m",
};

export const BADGES = {
  stable: `${C.brightGreen}[STABLE]${C.reset}`,
  flux: `${C.brightYellow}[FLUX]${C.reset}`,
  charged: `${C.brightMagenta}[CHARGED]${C.reset}`,
  error: `${C.brightRed}[ERROR]${C.reset}`,
};

function formatBytes(bytes) {
  if (bytes === 0) return "0 B";
  const k = 1024;
  const sizes = ["B", "KB", "MB", "GB", "TB"];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i];
}

export async function executeEnglishCommand(rawInput, workingDir = process.cwd()) {
  const input = rawInput.trim();
  if (!input) {
    return { status: "noop", message: "Empty command received." };
  }

  const lower = input.toLowerCase();

  // --- MOVIEFORGE THEATER & TEXT-TO-VIDEO CINEMATICS ---
  if (/(?:switch|set)\s+(?:theater|lut)(?:\s+to)?\s+([a-zA-Z\s]+)/i.test(input)) {
    const match = input.match(/(?:switch|set)\s+(?:theater|lut)(?:\s+to)?\s+([a-zA-Z\s]+)/i);
    const lut = match ? match[1].trim() : "imperial-gold";
    console.log(`\n${BADGES.charged} ${C.brightCyan}MovieForge 4K Neural Theater:${C.reset} Switching LUT to ${C.gold}${lut.toUpperCase()}${C.reset}`);
    try {
      await fetch("http://localhost:3000/api/theater/lut", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ lut })
      });
      console.log(`  ${C.green}✓ Color grading LUT live-applied via WebSocket stream.${C.reset}`);
      return { status: "success", lut };
    } catch (e) {
      console.log(`  ${C.red}Failed to reach theater server: ${e.message}${C.reset}`);
      return { status: "error", error: e.message };
    }
  }

  if (/^(?:open|launch)\s+(?:movieforge|theater|neural\s+theater)/i.test(input)) {
    console.log(`\n${BADGES.stable} ${C.brightCyan}Opening MovieForge 4K Neural Theater...${C.reset}`);
    try {
      execSync(`start http://localhost:3000/arcade`);
      return { status: "success", url: "http://localhost:3000/arcade" };
    } catch (e) {
      return { status: "error", error: e.message };
    }
  }

  if (/(?:pause|stop)\s+(?:neural\s+playback|theater|playback)/i.test(input)) {
    console.log(`\n${BADGES.stable} ${C.brightCyan}MovieForge Theater:${C.reset} Playback paused.`);
    return { status: "success", action: "pause" };
  }

  if (/(?:play|resume)\s+(?:neural\s+playback|theater|playback)/i.test(input)) {
    console.log(`\n${BADGES.stable} ${C.brightCyan}MovieForge Theater:${C.reset} Playback resumed.`);
    return { status: "success", action: "play" };
  }

  if (/^(?:generate|create|render)\s+video(?:\s+program)?(?:\s*:\s*|\s+)(.+)/i.test(input)) {
    const match = input.match(/^(?:generate|create|render)\s+video(?:\s+program)?(?:\s*:\s*|\s+)(.+)/i);
    const promptText = match ? match[1] : "Epic drone sweep";
    console.log(`\n${BADGES.charged} ${C.brightCyan}Text-to-Video Unreal Program Director:${C.reset}`);
    console.log(`  ${C.gray}Prompt:${C.reset} "${promptText}"`);
    try {
      const res = await fetch("http://localhost:3000/api/cinematics/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt: promptText, duration: 8, fps: 60 })
      });
      const data = await res.json();
      if (data.success) {
        console.log(`  ${C.green}✓ Sequence synthesized:${C.reset} ${data.sequence.id} (${data.sequence.angle})`);
        console.log(`  ${C.gold}Lens:${C.reset} ${data.sequence.lens.focalLength} | ${data.sequence.lens.aspectRatio}`);
        console.log(`  ${C.magenta}Biome:${C.reset} ${data.sequence.biome} | LUT: ${data.sequence.lut}`);
        return { status: "success", sequence: data.sequence };
      }
    } catch (e) {
      return { status: "error", error: e.message };
    }
  }

  // --- 1. SYSTEM DIAGNOSTICS & TELEMETRY ---

  // Check memory / RAM
  if (/^(check\s+)?(memory(\s+usage)?|ram)$/i.test(input)) {
    const total = os.totalmem();
    const free = os.freemem();
    const used = total - free;
    const pct = ((used / total) * 100).toFixed(1);

    console.log(`\n${BADGES.stable} ${C.brightCyan}Memory Diagnostics:${C.reset}`);
    console.log(`  ${C.gray}Total RAM:${C.reset}  ${formatBytes(total)}`);
    console.log(`  ${C.gray}Used RAM:${C.reset}   ${formatBytes(used)} (${pct}%)`);
    console.log(`  ${C.gray}Free RAM:${C.reset}   ${formatBytes(free)}`);
    return { status: "success", data: { total, used, free, percentUsed: pct } };
  }

  // Check CPU load
  if (/^(check\s+)?(cpu(\s+load|\s+usage)?|cores)$/i.test(input)) {
    const cpus = os.cpus();
    console.log(`\n${BADGES.stable} ${C.brightCyan}CPU Diagnostics:${C.reset}`);
    console.log(`  ${C.gray}Model:${C.reset}       ${cpus[0]?.model || "x86_64"}`);
    console.log(`  ${C.gray}Cores:${C.reset}       ${cpus.length} physical/logical cores`);
    console.log(`  ${C.gray}Clock Speed:${C.reset} ${cpus[0]?.speed || 0} MHz`);
    return { status: "success", data: { cores: cpus.length, model: cpus[0]?.model } };
  }

  // Show disk space
  if (/(show\s+)?(disk\s+space|storage|drives)/i.test(input)) {
    console.log(`\n${BADGES.stable} ${C.brightCyan}Storage Volume Capacity:${C.reset}`);
    try {
      const psOut = execSync(
        `powershell -NoProfile -Command "Get-PSDrive -PSProvider FileSystem | Select-Object Name, @{N='FreeGB';E={[math]::Round($_.Free/1GB,2)}}, @{N='UsedGB';E={[math]::Round($_.Used/1GB,2)}} | Format-Table -AutoSize"`,
        { encoding: "utf8" }
      );
      console.log(psOut.trim());
      return { status: "success", raw: psOut };
    } catch (e) {
      console.log(`  ${C.red}Failed to query disk volumes: ${e.message}${C.reset}`);
      return { status: "error", error: e.message };
    }
  }

  // Show running processes
  if (/(show\s+)?(running\s+)?processes|process\s+list|top\s+processes/i.test(input)) {
    console.log(`\n${BADGES.charged} ${C.brightCyan}Active Process Monitor (Top by Working Set):${C.reset}`);
    try {
      const psOut = execSync(
        `powershell -NoProfile -Command "Get-Process | Sort-Object WorkingSet -Descending | Select-Object -First 15 Id, ProcessName, @{N='MemoryMB';E={[math]::Round($_.WorkingSet/1MB,1)}}, CPU | Format-Table -AutoSize"`,
        { encoding: "utf8" }
      );
      console.log(psOut.trim());
      return { status: "success", raw: psOut };
    } catch (e) {
      console.log(`  ${C.red}Process query error: ${e.message}${C.reset}`);
      return { status: "error", error: e.message };
    }
  }

  // --- 2. FILE & DIRECTORY DISK MUTATIONS ---

  // Create folder / directory: e.g. "create folder data/archives" or "mkdir build"
  const folderMatch = input.match(/^(?:create\s+(?:folder|dir(?:ectory)?)|make\s+(?:folder|dir(?:ectory)?)|mkdir)\s+["']?([^"']+)["']?$/i);
  if (folderMatch) {
    const targetPath = path.resolve(workingDir, folderMatch[1].trim());
    console.log(`${BADGES.flux} Creating directory: ${C.brightCyan}${targetPath}${C.reset}`);
    fs.mkdirSync(targetPath, { recursive: true });
    console.log(`  ${C.green}✓ Directory established on disk.${C.reset}`);
    return { status: "success", path: targetPath };
  }

  // Create file with content: e.g. "create file app.js with console.log('hello')"
  const createFileContentMatch = input.match(/^(?:create|make)\s+file\s+["']?([^"'\s]+)["']?\s+with(?:\s+content)?\s+([\s\S]+)$/i);
  if (createFileContentMatch) {
    const targetFile = path.resolve(workingDir, createFileContentMatch[1].trim());
    const content = createFileContentMatch[2].trim();
    console.log(`${BADGES.flux} Synthesizing file: ${C.brightCyan}${targetFile}${C.reset}`);
    const parentDir = path.dirname(targetFile);
    if (!fs.existsSync(parentDir)) fs.mkdirSync(parentDir, { recursive: true });
    fs.writeFileSync(targetFile, content, "utf8");
    console.log(`  ${C.green}✓ Wrote ${content.length} bytes to ${path.basename(targetFile)}.${C.reset}`);
    return { status: "success", file: targetFile, bytes: content.length };
  }

  // Create empty file: e.g. "create file notes.txt" or "touch notes.txt"
  const createEmptyFileMatch = input.match(/^(?:create\s+file|touch)\s+["']?([^"']+)["']?$/i);
  if (createEmptyFileMatch) {
    const targetFile = path.resolve(workingDir, createEmptyFileMatch[1].trim());
    console.log(`${BADGES.flux} Creating empty file: ${C.brightCyan}${targetFile}${C.reset}`);
    const parentDir = path.dirname(targetFile);
    if (!fs.existsSync(parentDir)) fs.mkdirSync(parentDir, { recursive: true });
    fs.writeFileSync(targetFile, "", "utf8");
    console.log(`  ${C.green}✓ File created.${C.reset}`);
    return { status: "success", file: targetFile };
  }

  // Append to file: e.g. "append "build complete" to build.log"
  const appendMatch = input.match(/^append\s+["']?([^"']+)["']?\s+to\s+["']?([^"']+)["']?$/i);
  if (appendMatch) {
    const content = appendMatch[1];
    const targetFile = path.resolve(workingDir, appendMatch[2].trim());
    console.log(`${BADGES.flux} Appending to: ${C.brightCyan}${targetFile}${C.reset}`);
    fs.appendFileSync(targetFile, content + os.EOL, "utf8");
    console.log(`  ${C.green}✓ Appended entry.${C.reset}`);
    return { status: "success", file: targetFile };
  }

  // Show first N lines of file: e.g. "show first 25 lines of server.py" or "head -n 25 server.py"
  const headMatch = input.match(/^(?:show\s+(?:the\s+)?first\s+(\d+)\s+lines?\s+of|head\s+-n\s+(\d+))\s+["']?([^"']+)["']?$/i);
  if (headMatch) {
    const linesCount = parseInt(headMatch[1] || headMatch[2], 10);
    const targetFile = path.resolve(workingDir, headMatch[3].trim());
    if (!fs.existsSync(targetFile)) {
      console.log(`${BADGES.error} File not found: ${targetFile}`);
      return { status: "error", message: "File not found" };
    }
    const lines = fs.readFileSync(targetFile, "utf8").split(/\r?\n/);
    const preview = lines.slice(0, linesCount);
    console.log(`\n${BADGES.stable} ${C.brightCyan}${path.basename(targetFile)} (First ${preview.length} lines):${C.reset}`);
    preview.forEach((l, i) => console.log(`  ${C.gray}${(i + 1).toString().padStart(3, " ")} |${C.reset} ${l}`));
    return { status: "success", lines: preview };
  }

  // Read / cat file: e.g. "read file config.json" or "view file app.js"
  const readMatch = input.match(/^(?:read\s+file|view\s+file|cat)\s+["']?([^"']+)["']?$/i);
  if (readMatch) {
    const targetFile = path.resolve(workingDir, readMatch[1].trim());
    if (!fs.existsSync(targetFile)) {
      console.log(`${BADGES.error} File not found: ${targetFile}`);
      return { status: "error", message: "File not found" };
    }
    const content = fs.readFileSync(targetFile, "utf8");
    console.log(`\n${BADGES.stable} ${C.brightCyan}${path.basename(targetFile)} (${content.length} bytes):${C.reset}`);
    const lines = content.split(/\r?\n/);
    if (lines.length > 50) {
      lines.slice(0, 50).forEach((l, i) => console.log(`  ${C.gray}${(i + 1).toString().padStart(3, " ")} |${C.reset} ${l}`));
      console.log(`  ${C.dim}... [${lines.length - 50} more lines truncated]${C.reset}`);
    } else {
      lines.forEach((l, i) => console.log(`  ${C.gray}${(i + 1).toString().padStart(3, " ")} |${C.reset} ${l}`));
    }
    return { status: "success", content };
  }

  // Delete / remove file: e.g. "delete file cache.tmp" or "remove file old.log"
  const deleteFileMatch = input.match(/^(?:delete\s+file|remove\s+file|rm)\s+["']?([^"']+)["']?$/i);
  if (deleteFileMatch) {
    const targetFile = path.resolve(workingDir, deleteFileMatch[1].trim());
    if (!fs.existsSync(targetFile)) {
      console.log(`${BADGES.error} File does not exist: ${targetFile}`);
      return { status: "error", message: "File does not exist" };
    }
    fs.unlinkSync(targetFile);
    console.log(`${BADGES.flux} ${C.brightYellow}Purged file from disk:${C.reset} ${targetFile}`);
    return { status: "success", removed: targetFile };
  }

  // Copy file or directory: e.g. "copy assets/ to backup/"
  const copyMatch = input.match(/^copy\s+["']?([^"']+)["']?\s+to\s+["']?([^"']+)["']?$/i);
  if (copyMatch) {
    const src = path.resolve(workingDir, copyMatch[1].trim());
    const dst = path.resolve(workingDir, copyMatch[2].trim());
    if (!fs.existsSync(src)) {
      console.log(`${BADGES.error} Source does not exist: ${src}`);
      return { status: "error", message: "Source not found" };
    }
    console.log(`${BADGES.flux} Duplicating: ${C.cyan}${src}${C.reset} -> ${C.cyan}${dst}${C.reset}`);
    fs.cpSync(src, dst, { recursive: true });
    console.log(`  ${C.green}✓ Copy completed.${C.reset}`);
    return { status: "success", src, dst };
  }

  // Zip directory: e.g. "zip my_folder into archive.zip"
  const zipMatch = input.match(/^zip\s+["']?([^"']+)["']?\s+into\s+["']?([^"']+)["']?$/i);
  if (zipMatch) {
    const src = path.resolve(workingDir, zipMatch[1].trim());
    const dst = path.resolve(workingDir, zipMatch[2].trim());
    console.log(`${BADGES.flux} Compressing archive: ${C.cyan}${src}${C.reset} -> ${C.gold}${dst}${C.reset}`);
    try {
      execSync(`powershell -NoProfile -Command "Compress-Archive -Path '${src}' -DestinationPath '${dst}' -Force"`, { encoding: "utf8" });
      console.log(`  ${C.green}✓ Archive compiled successfully.${C.reset}`);
      return { status: "success", archive: dst };
    } catch (e) {
      console.log(`  ${C.red}Compression error: ${e.message}${C.reset}`);
      return { status: "error", error: e.message };
    }
  }

  // Show largest N files in directory: e.g. "show largest 10 files in C:\data"
  const largestMatch = input.match(/^(?:show\s+)?largest\s+(\d+)\s+files(?:\s+in\s+["']?([^"']+)["']?)?$/i);
  if (largestMatch) {
    const count = parseInt(largestMatch[1], 10);
    const searchDir = path.resolve(workingDir, largestMatch[2]?.trim() || ".");
    console.log(`\n${BADGES.charged} ${C.brightCyan}Scanning for top ${count} heavyweight files in ${searchDir}...${C.reset}`);
    try {
      const psOut = execSync(
        `powershell -NoProfile -Command "Get-ChildItem -Path '${searchDir}' -File -Recurse -Depth 4 -ErrorAction SilentlyContinue | Sort-Object Length -Descending | Select-Object -First ${count} FullName, @{N='SizeMB';E={[math]::Round($_.Length/1MB,2)}} | Format-Table -AutoSize"`,
        { encoding: "utf8" }
      );
      console.log(psOut.trim());
      return { status: "success", raw: psOut };
    } catch (e) {
      console.log(`  ${C.red}Heavyweight scan error: ${e.message}${C.reset}`);
      return { status: "error", error: e.message };
    }
  }

  // Find all [type] files: e.g. "find all python files in src" or "find all json files"
  const findMatch = input.match(/^find\s+all\s+(\w+)\s+files(?:\s+in\s+["']?([^"']+)["']?)?$/i);
  if (findMatch) {
    const extRaw = findMatch[1].toLowerCase();
    const ext = extRaw === "python" ? "py" : extRaw === "javascript" ? "js" : extRaw === "typescript" ? "ts" : extRaw;
    const searchDir = path.resolve(workingDir, findMatch[2]?.trim() || ".");
    console.log(`\n${BADGES.charged} ${C.brightCyan}Searching for *.${ext} files in ${searchDir}...${C.reset}`);
    try {
      const psOut = execSync(
        `powershell -NoProfile -Command "Get-ChildItem -Path '${searchDir}' -Filter '*.${ext}' -File -Recurse -Depth 5 -ErrorAction SilentlyContinue | Select-Object -First 30 FullName | Format-Table -HideTableHeaders"`,
        { encoding: "utf8" }
      );
      const lines = psOut.trim().split(/\r?\n/).filter(Boolean);
      if (lines.length === 0) {
        console.log(`  ${C.gray}No *.${ext} files discovered in search scope.${C.reset}`);
      } else {
        lines.forEach(l => console.log(`  ${C.brightCyan}•${C.reset} ${l.trim()}`));
        console.log(`\n  ${C.green}Found ${lines.length} matching files.${C.reset}`);
      }
      return { status: "success", count: lines.length, files: lines };
    } catch (e) {
      console.log(`  ${C.red}Find error: ${e.message}${C.reset}`);
      return { status: "error", error: e.message };
    }
  }

  // Search for string in files: e.g. "search for "matrix" in files"
  const grepMatch = input.match(/^search\s+for\s+["']([^"']+)["']\s+in\s+files(?:\s+in\s+["']?([^"']+)["']?)?$/i);
  if (grepMatch) {
    const query = grepMatch[1];
    const searchDir = path.resolve(workingDir, grepMatch[2]?.trim() || ".");
    console.log(`\n${BADGES.charged} ${C.brightCyan}Grep search for "${query}" in ${searchDir}...${C.reset}`);
    try {
      const psOut = execSync(
        `powershell -NoProfile -Command "Select-String -Path '${searchDir}\\*.*' -Pattern '${query.replace(/'/g, "''")}' -SimpleMatch -List -ErrorAction SilentlyContinue | Select-Object -First 20 Path, LineNumber, Line | Format-Table -AutoSize"`,
        { encoding: "utf8" }
      );
      console.log(psOut.trim());
      return { status: "success", raw: psOut };
    } catch (e) {
      console.log(`  ${C.gray}No matches found or search query completed.${C.reset}`);
      return { status: "success", matches: 0 };
    }
  }

  // Count files: e.g. "count all json files"
  const countMatch = input.match(/^count\s+all\s+(\w+)\s+files(?:\s+in\s+["']?([^"']+)["']?)?$/i);
  if (countMatch) {
    const extRaw = countMatch[1].toLowerCase();
    const ext = extRaw === "python" ? "py" : extRaw === "javascript" ? "js" : extRaw;
    const searchDir = path.resolve(workingDir, countMatch[2]?.trim() || ".");
    try {
      const psOut = execSync(
        `powershell -NoProfile -Command "(Get-ChildItem -Path '${searchDir}' -Filter '*.${ext}' -File -Recurse -Depth 5 -ErrorAction SilentlyContinue | Measure-Object).Count"`,
        { encoding: "utf8" }
      );
      const count = psOut.trim();
      console.log(`\n${BADGES.stable} ${C.brightCyan}File Census:${C.reset} ${C.gold}${count}${C.reset} *.${ext} files located in ${searchDir}`);
      return { status: "success", count: parseInt(count, 10) };
    } catch (e) {
      return { status: "error", error: e.message };
    }
  }

  // --- 3. GENERAL HIGH-SPEED FALLBACK EXECUTION ---
  // If the command is another plain-English instruction, execute it through PowerShell safely
  console.log(`${BADGES.flux} Executing semantic directive via host substrate: ${C.dim}"${input}"${C.reset}`);
  try {
    const psOut = execSync(`powershell -NoProfile -Command "${input.replace(/"/g, '`"')}"`, {
      cwd: workingDir,
      encoding: "utf8",
      timeout: 30000
    });
    if (psOut.trim()) console.log(psOut.trim());
    return { status: "success", output: psOut };
  } catch (err) {
    console.log(`${BADGES.error} Could not automatically resolve command: ${err.message}`);
    return { status: "error", error: err.message };
  }
}

// CLI Direct Invocation
if (process.argv[1] && path.resolve(process.argv[1]) === path.resolve(new URL(import.meta.url).pathname.replace(/^\/([a-zA-Z]:)/, '$1'))) {
  const args = process.argv.slice(2);
  if (args.length === 0) {
    console.log(`${C.gold}PrimordiaOS English-to-Disk Executor (PCE)${C.reset}`);
    console.log(`Usage: node C:\\primordiaos\\primordia-executor.mjs "<english-command>"`);
    process.exit(0);
  }
  const cmd = args.join(" ");
  executeEnglishCommand(cmd).catch(err => {
    console.error(err);
    process.exit(1);
  });
}
